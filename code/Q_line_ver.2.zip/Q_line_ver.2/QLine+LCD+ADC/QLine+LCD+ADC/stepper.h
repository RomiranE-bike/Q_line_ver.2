/*
 * stepper.h
 *
 * Created: 7/27/2024 10:14:00
 *  Author: me
 */ 
//------------------------------------------------------------------------------------------------------
#ifndef STEPPER_H_
#define STEPPER_H_
//------------------------------------------------------------------------------------------------------
//#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#include "LCD.h"
#include "io.h"
#include "beep.h"
//---------------------------------------------------------------------------------------------------
#define    up_key                PA5              // input with pull-up // press the U button
#define    down_key              PA6                // input with pull-up // press the D button
#define    right_key             PA7                // input with pull-up // press the F button
#define    left_key              PA4                // input with pull-up // press the R button

#define    start_key             PB5                // input with pull-up // press the START button
#define    stop_key              PB4                // input with pull-up // short the NOP switch
#define    Start_Limit           PB6                // input with pull-up // short the Start Limit switch
#define    End_Limit             PB7                // input with pull-up // short the End Limit switch

#define    key_DDR            DDRB
#define    key_PORT           PORTB
#define    key_PIN            PINB

#define    button_DDR         DDRA
#define    button_PORT        PORTA
#define    button_PIN         PINA

#define    stepper_port          PORTC
#define    stepper_ddr           DDRC
//---------------------------------------------------------------------------------------------------
#define    message_1 " Q_Line   v.2.4 "
#define    message_2 "Start running!"
#define    message_3 " Line stoped !"
#define    message_4 " Line waiting!"
//---------------------------------------------------------------------------------------------------
#define        d_out    100     // subject ready to test delay  ms
#define        d_in     100     // subject input delay  ms
#define        d_line   10       // line stepper delay :10 ms if clock set to 8MHZ /1 ms if clock set to 1MHZ
#define        d_tools  10       // tools stepper delay :10 ms if clock set to 8MHZ /1 ms if clock set to 1MHZ
//---------------------------------------------------------------------------------------------------
void Forward();
void Reverse();
void turn_Right();
void turn_Left();
void turn_Up();
void turn_Down();
void test_Up();
void test_Down();
void Start();
void Stop();
//---------------------------------------------------------------------------------------------------
// turn_Right routine
 void turn_Right(){            // Rotate 4 low byte of PORTA Motor clockwise with Half step sequence

      beep();
      Set_Cursor(2,1);
      Write_String("turn Right>>>>");
                  while( (button_PIN &(1<<right_key))==0 && (key_PIN &(1<<Start_Limit))){     // defualt delay ==10     //1111 1101

                            stepper_port=0x09;  //step 8  0000 1001
                            _delay_ms(d_line);
                            stepper_port=0x08;  //step 7  0000 1000
                            _delay_ms(d_line);
                            stepper_port=0x0c;  //step 6  0000 1100
                            _delay_ms(d_line);
                            stepper_port=0x04;  //step 5  0000 0100
                            _delay_ms(d_line);
                            stepper_port=0x06;  //step 4  0000 0110
                            _delay_ms(d_line);
                            stepper_port=0x02;  //step 3  0000 0010
                            _delay_ms(d_line);
                            stepper_port=0x03;  //step 2  0000 0011
                            _delay_ms(d_line);
                            stepper_port=0x01;  //step 1  0000 0001
                            _delay_ms(d_line);
                            };
      Stop();

   }
//---------------------------------------------------------------------------------------------------
// turn_Left routine
 void turn_Left(){               // Rotate 4 low byte of PORTA Motor anticlockwise with Half step sequence
     beep();
     Set_Cursor(2,1);
     Write_String("<<<< turn Left");
                  while( (button_PIN &(1<<left_key))==0 && (key_PIN &(1<<End_Limit))){     // defualt delay ==10

                        stepper_port=0x01;  //step 1  0000 0001
                        _delay_ms(d_line);
                        stepper_port=0x03;  //step 2  0000 0011
                        _delay_ms(d_line);
                        stepper_port=0x02;  //step 3  0000 0010
                        _delay_ms(d_line);
                        stepper_port=0x06;  //step 4  0000 0110
                        _delay_ms(d_line);
                        stepper_port=0x04;  //step 5  0000 0100
                        _delay_ms(d_line);
                        stepper_port=0x0c;  //step 6  0000 1100
                        _delay_ms(d_line);
                        stepper_port=0x08;  //step 7  0000 1000
                        _delay_ms(d_line);
                        stepper_port=0x09;  //step 8  0000 1001
                        _delay_ms(d_line);
                    };
     Stop();
   }
//---------------------------------------------------------------------------------------------------
// turn_Up routine
void turn_Up(){         // Rotate 4 upper bit of PORTA Motor clockwise with Half step sequence
        beep();
        Clear();
        Set_Cursor(2,1);
        Write_String("Tools UP");

        while((button_PIN &(1<<up_key))==0){
                stepper_port=0x10;  //step 1   0001  0000
                _delay_ms(d_tools);
                stepper_port=0x30;  //step 2   0011  0000
                _delay_ms(d_tools);
                stepper_port=0x20;  //step 3   0010  0000
                _delay_ms(d_tools);
                stepper_port=0x60;  //step 4   0110  0000
                _delay_ms(d_tools);
                stepper_port=0x40;  //step 5   0100  0000
                _delay_ms(d_tools);
                stepper_port=0xc0;  //step 6   1100  0000
                _delay_ms(d_tools);
                stepper_port=0x80;  //step 7   1000  0000
                _delay_ms(d_tools);
                stepper_port=0x90;  //step 8   1001  0000
                _delay_ms(d_tools);
        };
        Stop();
    }
//---------------------------------------------------------------------------------------------------
// turn_Down routine
void turn_Down(){     // Rotate 4 upper bit of PORTA Motor clockwise with Half step sequence    //main stepper turn forward
        beep();
        Clear();
        Set_Cursor(2,1);
        Write_String("Tools Down");

        while((button_PIN &(1<<down_key))==0){   //sw4  // defualt delay ==1    //1111 0111
                stepper_port=0x90;  //step 8   1001  0000
                _delay_ms(d_tools);
                stepper_port=0x80;  //step 7   1000  0000
                _delay_ms(d_tools);
                stepper_port=0xc0;  //step 6   1100  0000
                _delay_ms(d_tools);
                stepper_port=0x40;  //step 5   0100  0000
                _delay_ms(d_tools);
                stepper_port=0x60;  //step 4   0110  0000
                _delay_ms(d_tools);
                stepper_port=0x20;  //step 3   0010  0000
                _delay_ms(d_tools);
                stepper_port=0x30;  //step 2   0011  0000
                _delay_ms(d_tools);
                stepper_port=0x10;  //step 1   0001  0000
                _delay_ms(d_tools);
          };
       Stop();

   }
//---------------------------------------------------------------------------------------------------
// test_Up routine
void test_Up(){        // Rotate 4 upper bit of PORTA Motor clockwise with Half step sequence
        int cycle;
        beep();
        Clear();
        Set_Cursor(2,1);
        Write_String("test_Up");

            for(cycle=0;cycle<500;cycle++){
                    stepper_port=0x10;  //step 1   0001  0000
                    _delay_ms(d_tools);
                    stepper_port=0x30;  //step 2   0011  0000
                    _delay_ms(d_tools);
                    stepper_port=0x20;  //step 3   0010  0000
                    _delay_ms(d_tools);
                    stepper_port=0x60;  //step 4   0110  0000
                    _delay_ms(d_tools);
                    stepper_port=0x40;  //step 5   0100  0000
                    _delay_ms(d_tools);
                    stepper_port=0xc0;  //step 6   1100  0000
                    _delay_ms(d_tools);
                    stepper_port=0x80;  //step 7   1000  0000
                    _delay_ms(d_tools);
                    stepper_port=0x90;  //step 8   1001  0000
                    _delay_ms(d_tools);
            };
        Stop();
    }
//---------------------------------------------------------------------------------------------------
// test_Down routine
void test_Down(){     // Rotate 4 upper bit of PORTA Motor clockwise with Half step sequence    //main stepper turn forward
        int cycle;
        beep();
        Clear();
        Set_Cursor(2,1);
        Write_String("test_Down");


            for(cycle=0;cycle<500;cycle++){   //sw4  // defualt delay ==1    //1111 0111
                    stepper_port=0x90;  //step 8   1001  0000
                    _delay_ms(d_tools);
                    stepper_port=0x80;  //step 7   1000  0000
                    _delay_ms(d_tools);
                    stepper_port=0xc0;  //step 6   1100  0000
                    _delay_ms(d_tools);
                    stepper_port=0x40;  //step 5   0100  0000
                    _delay_ms(d_tools);
                    stepper_port=0x60;  //step 4   0110  0000
                    _delay_ms(d_tools);
                    stepper_port=0x20;  //step 3   0010  0000
                    _delay_ms(d_tools);
                    stepper_port=0x30;  //step 2   0011  0000
                    _delay_ms(d_tools);
                    stepper_port=0x10;  //step 1   0001  0000
                    _delay_ms(d_tools);
              };
       Stop();

   }
//---------------------------------------------------------------------------------------------------
// Start routine
void Start(){
          beep();
          Set_Cursor(1,1);
          Write_String(message_1);         //message_1 "  Q_Line  v.2  "
          Set_Cursor(2,1);
          Write_String(message_2);         //message_2 " Start running "
          _delay_ms(50);
          //limit_Flag = key_PIN &(1<<Start_Limit);
          while((key_PIN &(1<<stop_key)) ){

                  if(key_PIN &(1<<Start_Limit)){
                        LED_ON;
                        Set_Cursor(2,1);
                        Write_String("Forward >>>>>>>");
						
                        while(key_PIN &(1<<Start_Limit)){
							 Forward();
                             if((key_PIN &(1<<stop_key))==0)       // breaking condition
                             break;
                             }//end of while

					    if((key_PIN &(1<<Start_Limit))==0){
                                 Stop();
                                 _delay_ms(d_out);
                                 test_Up();
                                 LED_off;
                                 Set_Cursor(2,1);
                                 Write_String("<<<<  Reverse");
								 
                                 while(key_PIN &(1<<End_Limit)){									  
									  Reverse();
                                      if((key_PIN &(1<<stop_key))==0)       // breaking condition
                                      break;                                     
                                     }//end of while

                                 if((key_PIN &(1<<End_Limit))==0){
                                        Stop();
                                        _delay_ms(d_in);
                                        test_Down();
                                       }//end of if
                                }//end of if
                      }//end of if

                  else{
                     Stop();
                  }
            }//end of while
 }
//---------------------------------------------------------------------------------------------------
// Forward routine
void Forward(){
            // Rotate 4 low byte of PORTA Motor clockwise with Half step sequence

                            stepper_port=0x09;  //step 8  0000 1001
                            _delay_ms(d_line);
                            stepper_port=0x08;  //step 7  0000 1000
                            _delay_ms(d_line);
                            stepper_port=0x0c;  //step 6  0000 1100
                            _delay_ms(d_line);
                            stepper_port=0x04;  //step 5  0000 0100
                            _delay_ms(d_line);
                            stepper_port=0x06;  //step 4  0000 0110
                            _delay_ms(d_line);
                            stepper_port=0x02;  //step 3  0000 0010
                            _delay_ms(d_line);
                            stepper_port=0x03;  //step 2  0000 0011
                            _delay_ms(d_line);
                            stepper_port=0x01;  //step 1  0000 0001
                            _delay_ms(d_line);

   }
//---------------------------------------------------------------------------------------------------
// Reverse routine
void Reverse(){
               // Rotate 4 low byte of PORTA Motor anticlockwise with Half step sequence

                        stepper_port=0x01;  //step 1  0000 0001
                        _delay_ms(d_line);
                        stepper_port=0x03;  //step 2  0000 0011
                        _delay_ms(d_line);
                        stepper_port=0x02;  //step 3  0000 0010
                        _delay_ms(d_line);
                        stepper_port=0x06;  //step 4  0000 0110
                        _delay_ms(d_line);
                        stepper_port=0x04;  //step 5  0000 0100
                        _delay_ms(d_line);
                        stepper_port=0x0c;  //step 6  0000 1100
                        _delay_ms(d_line);
                        stepper_port=0x08;  //step 7  0000 1000
                        _delay_ms(d_line);
                        stepper_port=0x09;  //step 8  0000 1001
                        _delay_ms(d_line);

    }
//---------------------------------------------------------------------------------------------------
// stop routine
   void Stop(){

        stepper_port=0x00;
        blink();
        //beep();

        //Clear();
        Set_Cursor(1,1);
        Write_String(message_1);                         //message_1 " Q_Line   v.2 "
        Set_Cursor(2,1);
        Write_String(message_3);                         // message_3 " Line stopped !"
        //delay_ms(50);             //100 ms
        //Shift_Right();
        //_delay_ms(50);
        //Shift_Left();
        //_delay_ms(50);
   }
//---------------------------------------------------------------------------------------------------
#endif /* STEPPER_H_ */
//------------------------------------------------------------------------------------------------------