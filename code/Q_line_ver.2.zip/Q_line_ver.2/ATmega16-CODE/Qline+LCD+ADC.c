//---------------------------------------------------------------------------------------------------
// Qline+LCD.c
// revision 2.2
// Created: 11/9/2023 20:55:00
// Author: me
//
//---------------------------------------------------------------------------------------------------
#include <mega16.h>
#include <io.h>        // Standard Input/Output functions
#include <delay.h>
#include "stepper.h"
//---------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------
    void main(void){

            set_Ports();
            Reset();
            lcd_init();
            delay_ms(20);
            Clear();
            delay_ms(20);



              while(1){

                      if(up_key==LOW){
                         turn_Up();
                      }

                      else if(down_key==LOW){
                          turn_Down();
                      }

                      else if(right_key==LOW){
                          turn_Right();
                      }

                      else if(left_key==LOW){
                          turn_Left();
                      }

                      else if(start_Button==LOW){
                          start_Flag=start_Button;
                          stop_Flag=stop_Button;
                          Start();
                      }

                      else {
                          Stop();
                      };


              };

       }
//----------------------------------------------------------------------------

