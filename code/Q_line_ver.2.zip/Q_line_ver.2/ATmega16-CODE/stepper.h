//---------------------------------------------------------------------------------------------------
// stepper.h
// revision 2.4
// Created: 12/06/2023 22:49:00
// Author: me
//
//---------------------------------------------------------------------------------------------------
#include <mega16.h>
#include <io.h>        // Standard Input/Output functions
#include <delay.h>
#include "LCD.h"
//---------------------------------------------------------------------------------------------------
void set_Ports();

void Forward();
void Reverse();
void turn_Right();
void turn_Left();
void turn_Up();
void turn_Down();
void test_Up();
void test_Down();
void Start();
void Stop();
//---------------------------------------------------------------------------------------------------
void beep();
void blink();
//---------------------------------------------------------------------------------------------------
#define    LED                   PORTD.6  // 20      PD6      // LED
#define    BUZ                   PORTD.7  // 21      PD7      // BUZZER
#define    up_key                PINB.0  // 1        PB2      // input with pull-up // press the U button
#define    down_key              PINB.1  // 2        PB2      // input with pull-up // press the D button
#define    right_key             PINB.2  // 3        PB2      // input with pull-up // press the F button
#define    left_key              PINB.3  // 4        PB2      // input with pull-up // press the R button
#define    Start_Limit           PINB.4  // 5        PB2      // input with pull-up // short the Start Limit switch
#define    End_Limit             PINB.5  // 6        PB2      // input with pull-up // short the End Limit switch
#define    stop_Button           PINB.6  // 7        PB2      // input with pull-up // short the NOP switch
#define    start_Button          PINB.7  // 8        PB2      // input with pull-up // press the START button
//---------------------------------------------------------------------------------------------------
#define    message_1 " Q_Line   v.2.4 "
#define    message_2 "Start running!"
#define    message_3 " Line stoped !"
//#define   message_4 " Line waiting!"
//---------------------------------------------------------------------------------------------------
const int  HIGH =1;
const int  LOW=0;
int        d_line=1;      // line stepper delay :1 ms if clock set to 4MHZ/1 ms if clock set to 1MHZ
int        d_tools=1;     // tools stepper delay :1 ms if clock set to 4MHZ/ 1 ms if clock set to 1MHZ
int        f_beep=250;     //beep frequency :250 cycle  if  clock set to 8MHZ/ 500 cycle if clock set to 1MHZ
const int  d_beep=250;      //beep delay :250us if clock set to 4MHZ /50us if clock set to 1MHZ
int        d_blink=100;     //beep delay :100 ms if clock set to 4MHZ /100 ms if clock set to 1MHZ
int        d_out=100;    // subject ready to test delay 5000 ms
int        d_in=100;     // subject input delay 2000 ms
int        start_Flag;
int        stop_Flag;
int        limit_Flag;
//---------------------------------------------------------------------------------------------------
/*---------------------------------------------------------------------------------------------------
//state of all button inpot is: PB0:up  PB1:down PB2: forward PB3:reverse
//PB4:start limit PB5:end limit PB6:nop PB7:start button
//PD0..PD5: reserved PC0...PC7:reserved PD6:LED PD7:buzzer
//PA0...PA3:line stepper PA4...PA7:tools stepper
----------------------------------------------------------------------------------------------------
//PINB==0xfe | PINB==0xfd | PINB==0xfb | PINB==0xf7  manual mode
      stepDown();              //1111 1110  0xfe
      stepUp();                //1111 1101  0xfd
      stepForward();           //1111 1011  0xfb
      stepReverse();           //1111 0111  0xf7
      stepRun();               //1110 1111 or  1101 1111   or  1011 1111
                                  //0xef            0xdf            0xbf
//if PORTB=0xff enable all pull-ups  //if PORTB=0x00 disable pull-ups and make it tri state
---------------------------------------------------------------------------------------------------*/
//---------------------------------------------------------------------------------------------------
   void set_Ports(){

            DDRA=0xff;       //set all pins of port A as outpout
            PORTA=0x00;      //set all pins of port A LOW

            DDRB=0x00;      //make all pins of port B as input
            PORTB=0xff;     //enable all pins of port B pull-ups

            DDRC =0xff;     //set all pins of port C as outpout
            PORTC =0x00;    //set all pins of port C LOW

            DDRD =0xff;     //set all pins of port D as outpout
            PORTD =0x00;    //set all pins of port D LOW
   }
//---------------------------------------------------------------------------------------------------
   void turn_Right(){            // Rotate 4 low byte of PORTA Motor clockwise with Half step sequence

      beep();
      Set_Cursor(2,1);
      Write_String("turn Right>>>>");
                  while(right_key==LOW && Start_Limit !=LOW) {     // defualt delay ==10     //1111 1101

                            PORTA=0x09;  //step 8  0000 1001
                            delay_ms(d_line);
                            PORTA=0x08;  //step 7  0000 1000
                            delay_ms(d_line);
                            PORTA=0x0c;  //step 6  0000 1100
                            delay_ms(d_line);
                            PORTA=0x04;  //step 5  0000 0100
                            delay_ms(d_line);
                            PORTA=0x06;  //step 4  0000 0110
                            delay_ms(d_line);
                            PORTA=0x02;  //step 3  0000 0010
                            delay_ms(d_line);
                            PORTA=0x03;  //step 2  0000 0011
                            delay_ms(d_line);
                            PORTA=0x01;  //step 1  0000 0001
                            delay_ms(d_line);
                            };
      Stop();

   }
//---------------------------------------------------------------------------------------------------
   void turn_Left(){               // Rotate 4 low byte of PORTA Motor anticlockwise with Half step sequence
     beep();
     Set_Cursor(2,1);
     Write_String("<<<< turn Left");
                  while(left_key==LOW && End_Limit !=LOW){     // defualt delay ==10

                        PORTA=0x01;  //step 1  0000 0001
                        delay_ms(d_line);
                        PORTA=0x03;  //step 2  0000 0011
                        delay_ms(d_line);
                        PORTA=0x02;  //step 3  0000 0010
                        delay_ms(d_line);
                        PORTA=0x06;  //step 4  0000 0110
                        delay_ms(d_line);
                        PORTA=0x04;  //step 5  0000 0100
                        delay_ms(d_line);
                        PORTA=0x0c;  //step 6  0000 1100
                        delay_ms(d_line);
                        PORTA=0x08;  //step 7  0000 1000
                        delay_ms(d_line);
                        PORTA=0x09;  //step 8  0000 1001
                        delay_ms(d_line);
                    };
     Stop();
   }
//---------------------------------------------------------------------------------------------------
   void turn_Up(){         // Rotate 4 uppear bit of PORTA Motor clockwise with Half step sequence
        beep();
        Clear();
        Set_Cursor(2,1);
        Write_String("Tools UP");

        while(up_key==LOW ){
                PORTA=0x10;  //step 1   0001  0000
                delay_ms(d_tools);
                PORTA=0x30;  //step 2   0011  0000
                delay_ms(d_tools);
                PORTA=0x20;  //step 3   0010  0000
                delay_ms(d_tools);
                PORTA=0x60;  //step 4   0110  0000
                delay_ms(d_tools);
                PORTA=0x40;  //step 5   0100  0000
                delay_ms(d_tools);
                PORTA=0xc0;  //step 6   1100  0000
                delay_ms(d_tools);
                PORTA=0x80;  //step 7   1000  0000
                delay_ms(d_tools);
                PORTA=0x90;  //step 8   1001  0000
                delay_ms(d_tools);
        };
        Stop();
    }
//---------------------------------------------------------------------------------------------------
   void turn_Down(){     // Rotate 4 uppear bit of PORTA Motor clockwise with Half step sequence    //main stepper turn forward
        beep();
        Clear();
        Set_Cursor(2,1);
        Write_String("Tools Down");

        while(down_key==LOW){   //sw4  // defualt delay ==1    //1111 0111
                PORTA=0x90;  //step 8   1001  0000
                delay_ms(d_tools);
                PORTA=0x80;  //step 7   1000  0000
                delay_ms(d_tools);
                PORTA=0xc0;  //step 6   1100  0000
                delay_ms(d_tools);
                PORTA=0x40;  //step 5   0100  0000
                delay_ms(d_tools);
                PORTA=0x60;  //step 4   0110  0000
                delay_ms(d_tools);
                PORTA=0x20;  //step 3   0010  0000
                delay_ms(d_tools);
                PORTA=0x30;  //step 2   0011  0000
                delay_ms(d_tools);
                PORTA=0x10;  //step 1   0001  0000
                delay_ms(d_tools);
          };
       Stop();

   }
//---------------------------------------------------------------------------------------------------
   void test_Up(){        // Rotate 4 uppear bit of PORTA Motor clockwise with Half step sequence
        int cycle;
        beep();
        Clear();
        Set_Cursor(2,1);
        Write_String("test_Up");

            for(cycle=0;cycle<500;cycle++){
                    PORTA=0x10;  //step 1   0001  0000
                    delay_ms(d_tools);
                    PORTA=0x30;  //step 2   0011  0000
                    delay_ms(d_tools);
                    PORTA=0x20;  //step 3   0010  0000
                    delay_ms(d_tools);
                    PORTA=0x60;  //step 4   0110  0000
                    delay_ms(d_tools);
                    PORTA=0x40;  //step 5   0100  0000
                    delay_ms(d_tools);
                    PORTA=0xc0;  //step 6   1100  0000
                    delay_ms(d_tools);
                    PORTA=0x80;  //step 7   1000  0000
                    delay_ms(d_tools);
                    PORTA=0x90;  //step 8   1001  0000
                    delay_ms(d_tools);
            };
        Stop();
    }
//---------------------------------------------------------------------------------------------------
   void test_Down(){     // Rotate 4 uppear bit of PORTA Motor clockwise with Half step sequence    //main stepper turn forward
        int cycle;
        beep();
        Clear();
        Set_Cursor(2,1);
        Write_String("test_Down");


            for(cycle=0;cycle<500;cycle++){   //sw4  // defualt delay ==1    //1111 0111
                    PORTA=0x90;  //step 8   1001  0000
                    delay_ms(d_tools);
                    PORTA=0x80;  //step 7   1000  0000
                    delay_ms(d_tools);
                    PORTA=0xc0;  //step 6   1100  0000
                    delay_ms(d_tools);
                    PORTA=0x40;  //step 5   0100  0000
                    delay_ms(d_tools);
                    PORTA=0x60;  //step 4   0110  0000
                    delay_ms(d_tools);
                    PORTA=0x20;  //step 3   0010  0000
                    delay_ms(d_tools);
                    PORTA=0x30;  //step 2   0011  0000
                    delay_ms(d_tools);
                    PORTA=0x10;  //step 1   0001  0000
                    delay_ms(d_tools);
              };
       Stop();

   }
//---------------------------------------------------------------------------------------------------

   void Start(){
          beep();
          Set_Cursor(1,1);
          Write_String(message_1);         //message_1 "  Q_Line  v.2  "
          Set_Cursor(2,1);
          Write_String(message_2);         //message_2 " Start running "
          delay_ms(50);
          limit_Flag=Start_Limit;
          while(stop_Button !=LOW){

                  if(limit_Flag !=LOW){
                        LED=HIGH;
                        Set_Cursor(2,1);
                        Write_String("Forwared >>>>");
                        while(Start_Limit !=LOW){
                             if(stop_Button==LOW)       // breaking condition
                             break;
                             Forward();
                        };

                        if(Start_Limit==LOW){
                                 Stop();
                                 Set_Cursor(2,1);
                                 Write_String("<<<<  Reverse");
                                 delay_ms(d_out);
                                 test_Up();
                                 LED=LOW;

                                 while(End_Limit !=LOW){
                                      if(stop_Button==LOW)       // breaking condition
                                      break;
                                      Reverse();
                                 };

                                 if(End_Limit==LOW){
                                        Stop();
                                        delay_ms(d_in);
                                        test_Down();
                                   }
                          }
                  }

                  else{
                     Stop();
                  };
       };
    }
//---------------------------------------------------------------------------------------------------
   void Forward(){
            // Rotate 4 low byte of PORTA Motor clockwise with Half step sequence

                            PORTA=0x09;  //step 8  0000 1001
                            delay_ms(d_line);
                            PORTA=0x08;  //step 7  0000 1000
                            delay_ms(d_line);
                            PORTA=0x0c;  //step 6  0000 1100
                            delay_ms(d_line);
                            PORTA=0x04;  //step 5  0000 0100
                            delay_ms(d_line);
                            PORTA=0x06;  //step 4  0000 0110
                            delay_ms(d_line);
                            PORTA=0x02;  //step 3  0000 0010
                            delay_ms(d_line);
                            PORTA=0x03;  //step 2  0000 0011
                            delay_ms(d_line);
                            PORTA=0x01;  //step 1  0000 0001
                            delay_ms(d_line);

   }
//---------------------------------------------------------------------------------------------------
   void Reverse(){
               // Rotate 4 low byte of PORTA Motor anticlockwise with Half step sequence

                        PORTA=0x01;  //step 1  0000 0001
                        delay_ms(d_line);
                        PORTA=0x03;  //step 2  0000 0011
                        delay_ms(d_line);
                        PORTA=0x02;  //step 3  0000 0010
                        delay_ms(d_line);
                        PORTA=0x06;  //step 4  0000 0110
                        delay_ms(d_line);
                        PORTA=0x04;  //step 5  0000 0100
                        delay_ms(d_line);
                        PORTA=0x0c;  //step 6  0000 1100
                        delay_ms(d_line);
                        PORTA=0x08;  //step 7  0000 1000
                        delay_ms(d_line);
                        PORTA=0x09;  //step 8  0000 1001
                        delay_ms(d_line);

    }
//---------------------------------------------------------------------------------------------------
   void Stop(){

        PORTA=0x00;
        blink();
        beep();

        Clear();
        Set_Cursor(1,1);
        Write_String(message_1);                         //message_1 " Q_Line   v.2 "
        Set_Cursor(2,1);
        Write_String(message_3);                         // message_3 " Line stoped !"
        //delay_ms(50);             //100 ms
        Shift_Right();
        delay_ms(50);
        Shift_Left();
        delay_ms(50);
   }
//---------------------------------------------------------------------------------------------------
   void blink(){                // blinking routine
      LED=HIGH;                  // Toggle LED
      delay_ms(d_blink);         // Delay
      LED=LOW;                   // Toggle LED
      delay_ms(d_blink);         // Delay
   }
//---------------------------------------------------------------------------------------------------
   void beep(){                   // Beeping routine

        int i;
        for(i=0;i<f_beep;i++){       // Loop
            BUZ=HIGH;             // Toggle BUZZER
            delay_us(d_beep);         // Delay
            BUZ=LOW;              // Toggle BUZZER
            delay_us(d_beep);         // Delay
           };
   }
//---------------------------------------------------------------------------------------------------
