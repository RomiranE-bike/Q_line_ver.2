#include <io.h>
#include <delay.h>
#include <interrupt.h>
#include <sleep.h>
#include <wdt.h>
//--------------------------------------------------------------------------------------------
#define Button  1
#define Button_status !((PINB >> Button) & 0x01)
//--------------------------------------------------------------------------------------------
  enum STATUS{
    RUNNING,
    POWER_OFF,
  };
  //--------------------------------------------------------------------------------------------
   STATUS device_status;                        // Device status
//--------------------------------------------------------------------------------------------
  void device_off(){
    cli();                                  // Disable Interrupts before next commands
    wdt_disable();                          // Disable watch dog timer to save power
    set_sleep_mode(SLEEP_MODE_PWR_DOWN);    // Set sleep mode power down
    sleep_enable();
    sleep_bod_disable();                    // Disable Brown out detector
    sei();                                  // Enable interrupts
    sleep_cpu();
    sleep_disable();
  }

//--------------------------------------------------------------------------------------------
  int main(){
    PORTB |= (1 << Button);                // Enable PULL_UP resistor
    GIMSK |= (1 << PCIE);                  // Enable Pin Change Interrupts
    PCMSK |= (1 << Button);                // Use PCINTn as interrupt pin
    sei();                                 // Enable interrupts
    device_status = RUNNING;                      // Start ON/OFF when power is connected
    DDRB |= (1 << DDB0);                   //Set pin 0 to output for the LED

        for (;;){
                if (device_status == RUNNING){
                    PORTB |= (1 << PB0);   // LED Pin 0 ON
                }

                else{
                    PORTB &= ~(1 << PB0);  // LED Pin 0 OFF
                    device_off();
                }
        }
  }
//--------------------------------------------------------------------------------------------
  ISR(PCINT0_vect){
          if (Button_status){                    //If button is down change status{
                if (device_status == RUNNING){
                    device_status = POWER_OFF;
                    else{
                        device_status = RUNNING;
                        /* initialize the device here (timers etc..)*/
                    }
                 }
          }
   }
//--------------------------------------------------------------------------------------------